#!/bin/bash

commonVersionFile="version-running.txt"
releaseDir="releases"